﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
// importamos una libreria, que nos ayudara a las interacciones Para preguntar al usuario.
using Microsoft.VisualBasic;

namespace PARCIAL_FINAL_LAB_1_DABD1249321
{
    public partial class Form1 : Form
    {
        //Declaramos las variables ( Dos tipo int que representan a las columnas y generamos 4 matrices, 2 string el cual representa la matriz de la estructa del hotel y los nombres del cleinte y una tipo double
        // que representa el precio, y boleana que representa la habilitación de las habitaciones.
        int Fil = 0;
        int c0l = 0;
        //Se declara una variable tipo bool para verificar si esta dispoble el hotel (declarando un contador).
        int DisponibilidadHotel = 0;

        string[,] MatrizNombreCliente;
        bool[,] Habitaciones;

        public Form1()
        {
            InitializeComponent();
        }
        //Verificación del AirBnB si esta léno o no.
        public void ValidaDisponibilidadAirBnB()
        {
            
            for(int x =0; x < Fil; x++)
            {
                for (int y = 0; y < c0l; y++)
                {
                    if (Habitaciones[x,y] == false)
                    {
                        DisponibilidadHotel++;
                    }

                }

            }
        }
        //Se verfica el estado de la habiatación si esta disponible o no. O si esta lleno el AirBnB.
        public void ObtenerHabitacionCliente(ref int nivel, ref int recamara)
        {
            Random NRD = new Random();
            nivel = NRD.Next(2, Fil-1);
            recamara = NRD.Next(1, c0l+1);
            bool EstadoDisponible = false;
            while (EstadoDisponible == false)
            {
                for (int a = 0; a < Fil; a++)
                {
                    for (int b = 0; b < c0l; b++)
                    {
                        if (Habitaciones[a, b])
                        {
                            EstadoDisponible = true;
                        }
                        else
                        {
                            EstadoDisponible = false;
                        }
                    }
                }
             
            }
        }
        //Se hace el procemiento de los estados premium
        public void VereficarEstadosPremium(ref bool ESTADO2, int NIVEL, int RECAMARA)
        {
           
            ESTADO2 = Habitaciones[NIVEL-1, RECAMARA-1];
            
        }

        //Se crea un procedmiento (no devulve valores), que carga el DataGridView y añade las columnas y las filas.
        public void ActualizarGriv()
        {
            for (int a = 0; a < Fil; a++)
            {
                for (int b = 0; b < c0l; b++)
                {
                    if (Habitaciones[a, b])
                    {
                        DGVAirBnB.Rows[a].Cells[b].Value = (a + 1).ToString() + "0"+ (b+1).ToString();
                        DGVAirBnB.Rows[a].Cells[b].Style.BackColor = Color.Green;
                    }
                    else
                    {
                        DGVAirBnB.Rows[a].Cells[b].Value = (a + 1).ToString() + "0" + (b + 1).ToString();
                        DGVAirBnB.Rows[a].Cells[b].Style.BackColor = Color.SkyBlue;
                    }
                }
            }
        }
        // Se crea un procedimiento IncertarCliente
        public void InsertarCliente()
        {
            try
            {
                //Se verifica si esta disponible el AirBnB Primero.
                ValidaDisponibilidadAirBnB();
                if (DisponibilidadHotel-1 == Fil * c0l)
                {
                    MessageBox.Show("HOTEL PETAOOO LLÉNO, VUELVE MAS PRINTO");
                    return;
                }
                //Declaramos las variables, Con una interacción de pestañas del form pidiendo los datos del cliente
                // como tipo de habitación, cuantas personas, y el nombre de quien se registra.
                string client3 = Interaction.InputBox("Ingrese el nombre del cliente", "AirBnB");
                double Pr3cio = Convert.ToDouble(Interaction.InputBox("Ingrese el tipo de habitanción de 100 o 200"));
                int Niv3l = 0;
                int r3camara = 0;
                string habitaci0n = "";
                bool Estado2 = false;
                //Se establece una condición si es de 100, establece que no escoja la primera fila y la ultima y se le mostrara al final El número aleatorio de us habitación
                //causando asi su total a pagar y gracias a las matrices habitaciones y nombre del cliente guardar la info y pintarlo del color.
                if (Pr3cio == 100.00)
                {
                    ObtenerHabitacionCliente(ref Niv3l, ref r3camara);
                    habitaci0n = Niv3l.ToString() + "0" + r3camara.ToString();
                    int NumeroDePersonas = Convert.ToInt32(Interaction.InputBox("Ingrese el número de Personas Totales"));
                    MessageBox.Show("Su habitación es: " + habitaci0n.ToString());
                    MessageBox.Show("El total a pagar es de: " + (NumeroDePersonas * Pr3cio).ToString());
                    MatrizNombreCliente[Niv3l - 1, r3camara - 1] = client3;
                    Habitaciones[Niv3l - 1, r3camara - 1] = false;
                    ActualizarGriv();


                }
                //Si escoje 200 se pregunta si desea el segundo o primer nivel y que escoja entre las ahbitaciones de dicha fila.
                // causando asi que el rocedimiento VerificandoEstadosPremium se comience su funcion de habiataciones de la matriz
                //, tambien su total a pagar y gracias a las matrices habitaciones y nombre del cliente guardar la info y pintarlo del color.
                else if (Pr3cio == 200.00)
                {
                    while (Estado2 == false)
                    {
                        Niv3l = Convert.ToInt32(Interaction.InputBox("Escoja el PRIMER NIVEL: " + "1" + " o ÚLTIMO NIVEL: " + Fil.ToString()));
                        r3camara = Convert.ToInt32(Interaction.InputBox("Escoja número de habitación entre 1 " + (Fil - 1).ToString()));
                        VereficarEstadosPremium(ref Estado2, Niv3l, r3camara);

                    }
                    int NumeroDePersonas = Convert.ToInt32(Interaction.InputBox("Ingrese el número de Personas Totales"));
                    habitaci0n = Niv3l.ToString() + "0" + r3camara.ToString();
                    MessageBox.Show("Su habitación es: " + habitaci0n.ToString());
                    MessageBox.Show("El total a pagar es de: " + (NumeroDePersonas * Pr3cio).ToString());
                    MatrizNombreCliente[Niv3l - 1, r3camara - 1] = client3;
                    Habitaciones[Niv3l - 1, r3camara - 1] = false;
                    ActualizarGriv();

                }
                else
                {
                    MessageBox.Show("Opción Inválida");
                }
            }catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        //Se cargara la DATAGRIDVIEW con el formato de tamñano indicado por el numero de filas y columnas y usuarios.
        public void CargarGrid()
        {
            // Se recorre la matriz con dos for 
            for (int a = 0; a < Fil; a++)
            {
                for (int b = 0; b < c0l; b++)
                {
                    //Esto se usa para dar tamaño a las celdas en el mostrar o cargar el datagrivview
                    DGVAirBnB.Columns[b].Width = 70;
                    DGVAirBnB.Rows[a].Height = 70;
                    Habitaciones[a, b] = true;
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //Al cargar el archivo declararemos una ventana de interacción con el usuario solicitando los siguientes datos, donde al mismo tiempo.
            //Decalraremos las matrices planteadas anterirormente.
            //Validando que se ingresen datos válidos.
            try
            {
                Fil = int.Parse(Interaction.InputBox("Ingrese el número de niveles del hotel", "AirBnB"));
                c0l = int.Parse(Interaction.InputBox("Ingrese el número de Habitaciones por nivel del hotel", "AirBnB"));

                MatrizNombreCliente = new string[Fil, c0l];
                Habitaciones = new bool[Fil, c0l];

                DGVAirBnB.RowCount = Fil;
                DGVAirBnB.ColumnCount = c0l;

                //Esta dara tamaño a DGV (mas estetica).
                DGVAirBnB.Width = 70 * c0l+3;
                DGVAirBnB.Height = 70 * Fil+3;

                CargarGrid();
                ActualizarGriv();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                Application.Exit();
            }
        }
        //Se con colocar en el formato grafico un boton donde llamas al procedimneto Insertar cliente.
        private void BTNCLIENTE_Click(object sender, EventArgs e)
        {
            InsertarCliente();
        }
        //Hacemos funcionar el boton
        private void BTNRetirar_Click(object sender, EventArgs e)
        {
            try {

                //Decalramos las variables con interaccion a pregutnar al usuario la habitacion y el nombre donde estaba el cliente.
                string IndicarNumeroHanitacion =Interaction.InputBox("Ingrese la habitacion");
                string IngreseDenuevoSunombre = Interaction.InputBox("Ingrese su nombre");
                string NivelR = "";
                string RecamaraR = "";
                int pos = 0;
                //Descomponemos la cadena para poder extraer la recamara donde estan las personas
                for (int i = 0; i < IndicarNumeroHanitacion.Length; i++)
                {
                    if (IndicarNumeroHanitacion[i].ToString() != "0" && NivelR.Length >= 1)
                    {
                        NivelR += IndicarNumeroHanitacion[i];
                    }
                    else
                    {
                        pos = i;
                        break;
                    }
                }
                //Convertir los valores a la inversa para que al mismo tiempo las recamaras se desalogen y se actualize en el DataGrivView y su verificación
                RecamaraR = IndicarNumeroHanitacion.Substring(pos, IndicarNumeroHanitacion.Length - 1).ToString();
                if (DGVAirBnB.Rows[Convert.ToInt32(NivelR) - 1].Cells[Convert.ToInt32(RecamaraR) - 1].Value.ToString() == IndicarNumeroHanitacion.ToString() && Convert.ToBoolean(Habitaciones[Convert.ToInt32(NivelR) - 1, Convert.ToInt32(RecamaraR) - 1]) == false && MatrizNombreCliente[Convert.ToInt32(NivelR) - 1, Convert.ToInt32(RecamaraR) - 1].ToString() == IngreseDenuevoSunombre)
                {
                    Habitaciones[Convert.ToInt32(NivelR) - 1, Convert.ToInt32(RecamaraR) - 1] = true;
                    MatrizNombreCliente[Convert.ToInt32(NivelR) - 1, Convert.ToInt32(RecamaraR) - 1] = "";
                    MessageBox.Show("Cliente retirado");
                    ActualizarGriv();
                }
                else
                {
                    MessageBox.Show("Cliente NO Encontrado");
                }

            } catch (Exception ex) {
                MessageBox.Show(ex.ToString());
            }

        }
    }
}
